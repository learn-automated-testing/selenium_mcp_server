"""Agent-specific tools for Selenium MCP server."""

import logging
import os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field

from ..tool_base import BaseTool, ToolSchema, ToolResult
from ..context import Context

logger = logging.getLogger(__name__)

# ============================================================================
# PLANNER AGENT TOOLS
# ============================================================================

class PlannerSetupParams(BaseModel):
    """Parameters for planner setup."""
    url: str = Field(description="URL of the web application to test")
    feature: str = Field(description="Name of the feature to create test plan for")

class PlannerSetupTool(BaseTool):
    """Setup page for test planning."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="planner_setup_page",
            description="Initialize the testing environment and navigate to the application for test planning",
            input_schema=PlannerSetupParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: PlannerSetupParams) -> ToolResult:
        """Setup page for test planning."""
        async def setup_action():
            driver = await context.ensure_browser()
            driver.get(params.url)

            # Capture initial snapshot
            await context.capture_snapshot()

            # Initialize planning session
            context.planning_session = {
                "feature": params.feature,
                "url": params.url,
                "scenarios": []
            }

            logger.info(f"🎯 Planning session started for: {params.feature}")
            return {
                "message": f"Planning session initialized for '{params.feature}'",
                "url": params.url,
                "ready": True
            }

        code = [
            f"# Initialize test planning for: {params.feature}",
            f"# Target URL: {params.url}"
        ]

        return ToolResult(
            code=code,
            action=setup_action,
            capture_snapshot=True,
            wait_for_network=True
        )

class PlannerSavePlanParams(BaseModel):
    """Parameters for saving test plan."""
    plan_content: str = Field(description="Complete test plan content in markdown format")
    filename: Optional[str] = Field(default=None, description="Optional filename for the test plan (defaults to feature name)")

class PlannerSavePlanTool(BaseTool):
    """Save test plan to file."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="planner_save_plan",
            description="Save the completed test plan to a markdown file",
            input_schema=PlannerSavePlanParams,
            tool_type="destructive"
        )

    async def handle(self, context: Context, params: PlannerSavePlanParams) -> ToolResult:
        """Save test plan to file."""
        async def save_action():
            # Get filename from params or session
            if params.filename:
                filename = params.filename
            elif hasattr(context, 'planning_session') and context.planning_session:
                feature = context.planning_session.get('feature', 'test-plan')
                filename = f"{feature.lower().replace(' ', '-')}.plan.md"
            else:
                filename = "test-plan.md"

            # Create plans directory if it doesn't exist
            plans_dir = Path.cwd() / "test-plans"
            plans_dir.mkdir(exist_ok=True)

            # Save the plan
            plan_path = plans_dir / filename
            plan_path.write_text(params.plan_content)

            logger.info(f"📄 Test plan saved to: {plan_path}")

            return {
                "message": f"Test plan saved successfully",
                "file": str(plan_path),
                "size": len(params.plan_content)
            }

        code = [
            "# Save test plan to file",
            f"# Content length: {len(params.plan_content)} characters"
        ]

        return ToolResult(
            code=code,
            action=save_action,
            capture_snapshot=False,
            wait_for_network=False
        )

# ============================================================================
# GENERATOR AGENT TOOLS
# ============================================================================

class GeneratorSetupParams(BaseModel):
    """Parameters for generator setup."""
    url: str = Field(description="URL of the web application to test")
    test_plan: str = Field(description="Path to test plan file or test plan content")

class GeneratorSetupTool(BaseTool):
    """Setup page for test generation."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="generator_setup_page",
            description="Initialize the test generation session and navigate to the application",
            input_schema=GeneratorSetupParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: GeneratorSetupParams) -> ToolResult:
        """Setup page for test generation."""
        async def setup_action():
            driver = await context.ensure_browser()
            driver.get(params.url)

            # Enable recording to track actions
            context.recording_enabled = True
            context.action_history = []

            # Capture initial snapshot
            await context.capture_snapshot()

            # Initialize generation session
            context.generation_session = {
                "test_plan": params.test_plan,
                "url": params.url,
                "tests": []
            }

            logger.info(f"🔧 Test generation session started")
            logger.info(f"📝 Recording enabled - all actions will be logged")

            return {
                "message": "Test generation session initialized",
                "url": params.url,
                "recording": True,
                "test_plan": params.test_plan[:200] + "..." if len(params.test_plan) > 200 else params.test_plan
            }

        code = [
            "# Initialize test generation session",
            f"# Target URL: {params.url}",
            "# Action recording: ENABLED"
        ]

        return ToolResult(
            code=code,
            action=setup_action,
            capture_snapshot=True,
            wait_for_network=True
        )

class GeneratorReadLogParams(BaseModel):
    """Parameters for reading action log."""
    pass

class GeneratorReadLogTool(BaseTool):
    """Read the action log for code generation."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="generator_read_log",
            description="Retrieve the log of all actions performed during test generation session",
            input_schema=GeneratorReadLogParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: GeneratorReadLogParams) -> ToolResult:
        """Read action log."""
        async def read_log_action():
            if not context.action_history:
                return {
                    "message": "No actions recorded yet",
                    "actions": []
                }

            # Format action history
            log_entries = []
            for i, action in enumerate(context.action_history, 1):
                log_entries.append({
                    "step": i,
                    "tool": action["tool"],
                    "params": action["params"]
                })

            logger.info(f"📋 Retrieved {len(log_entries)} recorded actions")

            return {
                "message": f"Retrieved {len(log_entries)} actions",
                "actions": log_entries,
                "total": len(log_entries)
            }

        code = [
            "# Retrieve action log for code generation",
            f"# Total actions recorded: {len(context.action_history)}"
        ]

        return ToolResult(
            code=code,
            action=read_log_action,
            capture_snapshot=False,
            wait_for_network=False
        )

class GeneratorWriteTestParams(BaseModel):
    """Parameters for writing test code."""
    test_code: str = Field(description="Generated test code")
    filename: str = Field(description="Filename for the test file (e.g., test_login.py)")
    framework: str = Field(default="pytest", description="Test framework (pytest, unittest, robot)")

class GeneratorWriteTestTool(BaseTool):
    """Write generated test code to file."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="generator_write_test",
            description="Save generated test code to a file",
            input_schema=GeneratorWriteTestParams,
            tool_type="destructive"
        )

    async def handle(self, context: Context, params: GeneratorWriteTestParams) -> ToolResult:
        """Write test code to file."""
        async def write_test_action():
            # Create tests directory if it doesn't exist
            tests_dir = Path.cwd() / "tests"
            tests_dir.mkdir(exist_ok=True)

            # Ensure proper file extension
            if not params.filename.endswith(('.py', '.robot')):
                if params.framework == 'robot':
                    params.filename += '.robot'
                else:
                    params.filename += '.py'

            # Save the test file
            test_path = tests_dir / params.filename
            test_path.write_text(params.test_code)

            # Clear action history after generating
            if context.recording_enabled:
                context.action_history = []

            logger.info(f"✅ Test code saved to: {test_path}")

            return {
                "message": f"Test code saved successfully",
                "file": str(test_path),
                "framework": params.framework,
                "lines": len(params.test_code.split('\n'))
            }

        code = [
            f"# Save {params.framework} test code",
            f"# File: {params.filename}",
            f"# Lines: {len(params.test_code.split('\n'))}"
        ]

        return ToolResult(
            code=code,
            action=write_test_action,
            capture_snapshot=False,
            wait_for_network=False
        )

# ============================================================================
# HEALER AGENT TOOLS
# ============================================================================

class HealerRunTestsParams(BaseModel):
    """Parameters for running tests."""
    test_path: str = Field(description="Path to test file or directory to run")
    framework: str = Field(default="pytest", description="Test framework to use")

class HealerRunTestsTool(BaseTool):
    """Run tests and collect failure information."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="healer_run_tests",
            description="Execute test suite and collect failure information for debugging",
            input_schema=HealerRunTestsParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: HealerRunTestsParams) -> ToolResult:
        """Run tests and collect failures."""
        async def run_tests_action():
            import subprocess

            # Build command based on framework
            if params.framework == "pytest":
                cmd = ["pytest", params.test_path, "-v", "--tb=short"]
            elif params.framework == "robot":
                cmd = ["robot", "--outputdir", "results", params.test_path]
            else:
                cmd = ["python", "-m", "unittest", params.test_path]

            # Run tests
            result = subprocess.run(cmd, capture_output=True, text=True)

            logger.info(f"🧪 Tests executed: {params.test_path}")

            return {
                "message": f"Tests executed",
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "passed": result.returncode == 0
            }

        code = [
            f"# Run {params.framework} tests",
            f"# Path: {params.test_path}"
        ]

        return ToolResult(
            code=code,
            action=run_tests_action,
            capture_snapshot=False,
            wait_for_network=False
        )

class HealerDebugTestParams(BaseModel):
    """Parameters for debugging a specific test."""
    test_name: str = Field(description="Name of the specific test to debug")
    test_path: str = Field(description="Path to the test file")

class HealerDebugTestTool(BaseTool):
    """Debug a specific failing test."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="healer_debug_test",
            description="Run a specific test in debug mode with enhanced logging",
            input_schema=HealerDebugTestParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: HealerDebugTestParams) -> ToolResult:
        """Debug specific test."""
        async def debug_test_action():
            import subprocess

            # Run specific test with verbose output
            cmd = ["pytest", f"{params.test_path}::{params.test_name}", "-vv", "-s", "--tb=long"]
            result = subprocess.run(cmd, capture_output=True, text=True)

            logger.info(f"🐛 Debugging test: {params.test_name}")

            return {
                "message": f"Debug run complete for {params.test_name}",
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "passed": result.returncode == 0
            }

        code = [
            f"# Debug test: {params.test_name}",
            f"# File: {params.test_path}"
        ]

        return ToolResult(
            code=code,
            action=debug_test_action,
            capture_snapshot=False,
            wait_for_network=False
        )

class HealerFixTestParams(BaseModel):
    """Parameters for fixing a test."""
    test_path: str = Field(description="Path to the test file to fix")
    fixed_code: str = Field(description="The corrected test code")
    fix_description: str = Field(description="Description of what was fixed")

class HealerFixTestTool(BaseTool):
    """Apply fix to a test file."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="healer_fix_test",
            description="Apply fixes to a test file and save the corrected version",
            input_schema=HealerFixTestParams,
            tool_type="destructive"
        )

    async def handle(self, context: Context, params: HealerFixTestParams) -> ToolResult:
        """Fix test file."""
        async def fix_test_action():
            # Save the fixed code
            test_path = Path(params.test_path)

            # Backup original
            backup_path = test_path.with_suffix(test_path.suffix + '.bak')
            if test_path.exists():
                backup_path.write_text(test_path.read_text())

            # Write fixed code
            test_path.write_text(params.fixed_code)

            logger.info(f"🔧 Fixed test: {params.test_path}")
            logger.info(f"📋 Fix: {params.fix_description}")

            return {
                "message": f"Test fixed and saved",
                "file": str(test_path),
                "backup": str(backup_path),
                "fix": params.fix_description
            }

        code = [
            f"# Fix applied to: {params.test_path}",
            f"# Description: {params.fix_description}",
            f"# Backup created: {params.test_path}.bak"
        ]

        return ToolResult(
            code=code,
            action=fix_test_action,
            capture_snapshot=False,
            wait_for_network=False
        )

class BrowserGenerateLocatorParams(BaseModel):
    """Parameters for generating element locator."""
    element_description: str = Field(description="Description of the element to find a locator for")

class BrowserGenerateLocatorTool(BaseTool):
    """Generate robust locator for an element."""

    def _create_schema(self) -> ToolSchema:
        return ToolSchema(
            name="browser_generate_locator",
            description="Generate a robust locator strategy for a specific element",
            input_schema=BrowserGenerateLocatorParams,
            tool_type="readOnly"
        )

    async def handle(self, context: Context, params: BrowserGenerateLocatorParams) -> ToolResult:
        """Generate element locator."""
        async def generate_locator_action():
            driver = context.current_tab_or_die()

            # Use snapshot to find matching elements
            if not context.current_snapshot:
                await context.capture_snapshot()

            # Find elements matching description
            matching_elements = []
            for ref, elem_info in context.current_snapshot.elements.items():
                if (params.element_description.lower() in (elem_info.text or "").lower() or
                    params.element_description.lower() in (elem_info.aria_label or "").lower()):
                    matching_elements.append((ref, elem_info))

            if matching_elements:
                ref, elem = matching_elements[0]
                by, locator = context.current_snapshot.ref_locator(ref)

                return {
                    "message": f"Generated locator for: {params.element_description}",
                    "strategy": by,
                    "locator": locator,
                    "element": {
                        "tag": elem.tag_name,
                        "text": elem.text,
                        "id": elem.attributes.get("id")
                    }
                }
            else:
                return {
                    "message": f"No matching element found for: {params.element_description}",
                    "suggestions": "Try capturing a new snapshot or providing a more specific description"
                }

        code = [
            f"# Generate locator for: {params.element_description}"
        ]

        return ToolResult(
            code=code,
            action=generate_locator_action,
            capture_snapshot=True,
            wait_for_network=False
        )
